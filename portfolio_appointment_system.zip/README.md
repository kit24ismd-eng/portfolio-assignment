# Portfolio + Appointment Booking System

A beginner-friendly starter project containing:
- Static responsive portfolio website (HTML + CSS + small JavaScript file)
- Appointment request form
- Python serverless API on Vercel
- Supabase PostgreSQL database
- GitHub repository for source control and Vercel deployment

The booking flow has Customer/Client and Service Provider roles. An Admin can review requests in the Supabase dashboard. This starter does **not** include a public admin login/dashboard, automated email notifications, or conflict-proof slot locking.

## 1. Test the static portfolio locally
Open `index.html` in a browser to preview the design. The booking submission will not work until the API is deployed and configured.

For full local testing, install Python 3.11+, then:
```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```
Vercel's local dev command can run the serverless API locally after installing the Vercel CLI:
```bash
npm install -g vercel
vercel dev
```
Set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` in your local environment before starting. Never commit real secrets.

## 2. Create the Supabase backend
1. Create a project at https://supabase.com/.
2. Open **SQL Editor**, create a query, paste `supabase/schema.sql`, and run it.
3. Open **Project Settings → API** (the exact labels may change).
4. Copy the project URL and the **service_role / secret server key**. Keep the key private.

The service-role key bypasses Row Level Security. It is used only by the Python server function and must never be exposed to the browser. For production, consider a narrower database role/RPC, CAPTCHA or rate limiting, stronger spam protection, and booking conflict rules.

## 3. Push the project to GitHub
1. Create a new empty repository on https://github.com/ (for example `portfolio-appointment-system`).
2. Extract this ZIP, open a terminal in the extracted project folder, and run:
```bash
git init
git add .
git commit -m "Build portfolio and appointment booking system"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/portfolio-appointment-system.git
git push -u origin main
```
Replace `YOUR_USERNAME` with your GitHub username. Do not commit the real Supabase key.

## 4. Deploy with Vercel
1. Open https://vercel.com/ and choose **Add New → Project**.
2. Import the GitHub repository.
3. In Project Settings → Environment Variables, add:
   - `SUPABASE_URL` = your Supabase project URL
   - `SUPABASE_SERVICE_ROLE_KEY` = your private service-role key
   - `ALLOWED_ORIGIN` = your deployed site origin, e.g. `https://your-project.vercel.app`
4. Deploy, then test the booking form on the live URL.
5. After changing environment variables, redeploy if prompted/required.

The included `vercel.json` routes `/api/bookings` to the Python function. If Vercel's current Python runtime/build configuration has changed, follow its current Python Functions documentation and adjust the config accordingly.

## 5. Verify a booking
1. Open your deployed site and fill in the appointment form with a future date.
2. Submit it; you should receive a booking reference.
3. In Supabase → Table Editor → `appointments`, verify the row appears.
4. Admin review: for this starter, view and update `status` in Supabase Table Editor. Do not expose the service-role key or build an admin page that uses it in browser JavaScript.

## Project structure
```text
portfolio-appointment-system/
├── index.html
├── style.css
├── script.js
├── api/
│   └── index.py
├── supabase/
│   └── schema.sql
├── requirements.txt
├── vercel.json
├── .env.example
├── .gitignore
└── README.md
```

## Personalize before submitting
- Change Alex Morgan and AM to your name/initials.
- Replace example project cards, skills, and contact email.
- Test mobile layout and the booking form.
- Add screenshots and a clear project description to GitHub.
- Make sure no API keys or passwords are in your commits.

## Important limitations
This is a starter/demo. It validates form inputs and stores booking requests, but it does not guarantee that two people cannot book the same time. It does not implement authenticated customer/provider/admin accounts, email confirmations, or a custom admin dashboard. Add those before using it for real appointments.
